# MAPF Benchmark

This tool aims to simplify the banchmarking of different algorithms
for the Multi Agent Path Finding (MAPF) problem.

For now, the tool is currently in alpha and not working

## Features

- 

## Installation

- Just clone the repository and run src/main.py


